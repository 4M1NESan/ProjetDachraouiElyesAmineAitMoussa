# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include "connection.h"
#include"gestlivres.h"

// afficher les livres empruntés
void afficheLivre(FILE* pl, Utilisateur u){
	//declaration variables
	int count=0;
	Livre l;
	
	printf("\nVoici les livres que vous avez emprunté:");
	rewind(pl);
	
	while(fread(&l, sizeof(Livre), 1, pl)!=0){
		if(strcmp(u.login, l.proprietaire)==0){
			printf("\n- %s de %s, à rendre à %d:%d", l.titre, l.auteur, l.d.heure, l.d.min);
			count=count+1;
		}
	}
	if(count==0){
		printf("\nVous n'avez emprunté aucun livre!\n");
	}
}



//emprunter les livres
void empruntLivre(Utilisateur u, FILE* pl, FILE* pu, int positionu){
	char livreemprunt[300];
	int verif=0, positionl;
	Livre l, lpivot;
	Utilisateur upivot;
	
	
	if(u.bloque==1){
		printf("\nVotre compte est bloqué. Vous ne pouvez plus emprunter de nouveau livre.\n");
		return ;
	}
	
	if(u.compteur==0){
		printf("\nVous avez emprunté le nombre maximun de livre. Veuillez rendre un livre avant de pouvoir emprunter un nouveau livre.\n");
		return ;
	}
	
	rewind(pl);
	positionl=0;
		
		
	printf("\nQuel est le titre du livre que vous souhaitez emprunter? Tapez ''q'' pour quitter le menu d'emprunt\n");
	getchar();
	scanf("%[^\n]",livreemprunt);
	if(strcmp(livreemprunt, "q")==0){
			return ; 
	}
		
		
	while(fread(&lpivot, sizeof(Livre), 1, pl)!=0){	
		positionl++;
		if(strcmp(lpivot.titre, livreemprunt)==0 && strcmp(lpivot.proprietaire, "o")==0){
			verif=1;
			l=lpivot;
			break;
		}
	}

	if(verif==0){
		printf("\nLe titre du livre a été mal saisi ou n'est pas disponible\n");
		return ;
		
	}
		
		
		
	
	rewind(pl);
	rewind(pu);
	do{
		printf("\nVeuillez taper l'heure actuelle.\n");
		scanf("%d",&l.d.heure);
		printf("\nVeuillez taper les minutes actuelle.\n");
		scanf("%d",&l.d.min);
	}while( l.d.heure< 0 && l.d.heure>23 && l.d.min<0 && l.d.min>59);
	
	if(strcmp(u.role, "professeur")==0){
		l.d.min=l.d.min+3;
	}
	
	else{
		l.d.min=l.d.min+2;
	}
	
	
	if(l.d.min>=60){
		l.d.min=l.d.min-60;
		l.d.heure=l.d.heure+1;
	}
	
	if(l.d.heure==24)
		l.d.heure=0;
	
	stpcpy(l.proprietaire, u.login);
	
	u.compteur= u.compteur-1;
	
	
	for(int i=0;i<positionl-1; i++){
		fread(&lpivot, sizeof(Livre),1, pl);
	}
	fwrite(&l, sizeof(Livre),1, pl);
	
	
	for(int j=0;j<positionu-1; j++){
		fread(&upivot, sizeof(Utilisateur),1, pu);
	}
	fwrite(&u, sizeof(Utilisateur),1, pu);
	
	printf("\nLe livre a bien été emprunté!\n");
	
}



//rendre livre
void rendreLivre(Utilisateur u, FILE* pl, FILE* pu, int positionu){
	char livrerend[300],reinproprio[300];
	int verif=0, positionl, heure, min, heureth, heurerendu, truth, heure1, min1;
	Livre l, lpivot;
	Utilisateur upivot;
	
	reinproprio[0]='o';
	reinproprio[1]='\0';
	rewind(pl);
	rewind(pu);
	positionl=0;
	
	printf("\nSaisissez le titre du livre que vous souhaitez rendre. Tapez ''q'' pour quitter le menu de rente\n");
	getchar();
	scanf("%[^\n]",livrerend);
	if(strcmp(livrerend, "q")==0){
			return ; 
	}
		
		
	while(fread(&lpivot, sizeof(Livre), 1, pl)!=0){	
		positionl++;
		if(strcmp(lpivot.titre, livrerend)==0 && strcmp(lpivot.proprietaire, u.login)==0){
			verif=1;
			l=lpivot;
			break;
		}
	}
		
	if(verif==0){
		printf("\nLe titre du livre a été mal saisi ou n'est pas emprunté par vous.\n");
		rendreLivre(u, pl, pu, positionu);
	}
	
	
	printf("\nQuelle heure est-il?(sans les minutes)\n");
	scanf("%d", &heure);
	printf("\nLes minutes?\n");
	scanf("%d", &min);
	heurerendu=min +(60*heure);
	heure1=l.d.heure;
	min1=l.d.min;
	heureth=(min1)+(60*(heure1));
	
	if(strcmp(u.role, "professeur")==0){
		
		if(heureth==2){
			if(heurerendu>=1439 || heurerendu<heureth){
				truth=0;
			}
			else{
				truth=1;
			}
		}
		
		else if(heureth==1){
			if(heurerendu>=1438 || heurerendu<=heureth){
				truth=0;
			}
			else{
				truth=1;
			}
		}
		
		
		else{
			if(heurerendu<=heureth){
				truth=0;
			}
			else{
				truth=1;
			}
		}
		
	}
	
	else{
		
		if(heureth==1){
			if(heurerendu>=1439 || heurerendu<=heureth){
				truth=0;
			}
			else{
				truth=1;
			}
		}
		
		else{
			if(heurerendu<=heureth){
				truth=0;
			}
			else{
				truth=1;
			}
		}
		
	}
	
	
	if(truth==1){
		printf("\nVotre compte est bloqué. Vous ne pourrez plus emprunter de livres dans notre bibliothèque.\n");
		u.bloque=1;
		for(int i=0; i<positionu-1; i++){
			fread(&upivot, sizeof(Utilisateur), 1, pu);
		}
		fwrite(&u, sizeof(Utilisateur), 1, pu);
		printf("\nPour rendre vos livres, veuillez indiquer l'heure 00:00.\n");
		return ;
		
	}
	else{
		u.compteur=u.compteur+1;
		strcpy(l.proprietaire, reinproprio);
		
		rewind(pl);
		rewind(pu);
		
	}
	
	
	
	for(int j=0;j<positionl-1; j++){
		fread(&lpivot, sizeof(Livre),1, pl);
	}
	fwrite(&l, sizeof(Livre),1, pl);
	
	
	for(int k=0;k<positionu-1; k++){
		fread(&upivot, sizeof(Utilisateur),1, pu);
	}
	fwrite(&u, sizeof(Utilisateur),1, pu);
	
	
	printf("\nLe livre a bien été rendu!\n");
	
	
}


