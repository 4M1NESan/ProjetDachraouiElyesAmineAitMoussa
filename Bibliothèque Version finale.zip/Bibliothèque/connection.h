#ifndef __CONNECTION__
#define __CONNECTION__
//Utilisateur
typedef struct{
    char role[50];
    char login[50];
    char mot_de_passe[200];
    int compteur;
    int bloque;
}Utilisateur;


//date
typedef struct{
    int heure;
	int min;
}Date;


//livre
typedef struct{
    char titre[300];
	char auteur[300];
	int numid;
	char categorie[300];
	char proprietaire[300];
	Date d;
}Livre;


Utilisateur connection(FILE *p);

#endif