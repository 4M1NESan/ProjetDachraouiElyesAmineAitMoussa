# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include"verification.h"
#include"connection.h"
//verification des logs et mdp
int verification(char newid[], char newpassword[], FILE* p){

	//DECLARATION VARIABLES
	Utilisateur u;
	
	
	rewind(p);


	//VERIFICATION DES CONDITIONS SUR L'ID

	//CONTIENT  QUE DES LETTRES?
	for(int j=0; j<strlen(newid);j++){
		if(!(isalpha(newid[j])) || strcmp(newid, "o")==0){
			printf("\nL'identifiant ne doit contenir que des lettres et doit être différent de ''o''.\n");
			return 0;
		}

	}		



	//IDENTIFIANT UNIQUE?
	while(fread(&u, sizeof(Utilisateur), 1, p)!=0){

		if(strcmp(newid, u.login)==0){// on compare l'id du doc et celui saisi
			printf("\nCet identifiant existe déjà, veuillez en choisir un autre\n");
			return 0;		
		}
	}


return 1;
}


