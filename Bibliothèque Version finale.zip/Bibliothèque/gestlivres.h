#ifndef __GESTIONLIVRE__
#define __GESTIONLIVRE__

void afficheLivre(FILE* pl, Utilisateur u);
void empruntLivre(Utilisateur u, FILE* pl, FILE* pu, int positionu);
void rendreLivre(Utilisateur u, FILE* pl, FILE* pu, int positionu);



#endif