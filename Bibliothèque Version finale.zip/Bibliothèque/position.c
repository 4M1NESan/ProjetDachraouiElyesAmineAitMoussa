# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include"position.h"
#include"connection.h"

//position utilisateur dans la base des données, le fichier
int positionUti(FILE* p, Utilisateur u){
	//DECLARATION DES VARIABLES
	Utilisateur uverif;
	int position=0;

	rewind(p);

	
	//VERIFICATION DES INFORMATIONS
	while(fread(&uverif, sizeof(Utilisateur), 1, p)!=0){
		position=position+1;
		if(strcmp(uverif.login, u.login)==0 && strcmp(uverif.mot_de_passe, u.mot_de_passe)==0){		
			
			return position;	
			
		}
	}
	
	return position;
}

