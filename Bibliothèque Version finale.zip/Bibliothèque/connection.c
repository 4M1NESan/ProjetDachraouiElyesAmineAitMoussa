# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include"connection.h"

//Connexion
Utilisateur connection(FILE *p){

	//DECLARATION DES VARIABLES
	Utilisateur u;
	char identifiant[300];
	char mdp[300];
	int positionu=0;
	



	//RECUPERATION DE L'ID ET DU MDP DE L'UTILISATEUR
	printf("\n Bonjour, quel est votre indentifiant?\n");
	scanf("%s", identifiant);
	printf("\n Quel est votre mot de passe?\n");
	scanf("%s", mdp);

	rewind(p);

	
	//VERIFICATION DES INFORMATIONS 
	while(fread(&u, sizeof(Utilisateur), 1, p)!=0){

		if(strcmp(identifiant, u.login)==0 && strcmp(mdp, u.mot_de_passe)==0){
			printf("\nConnexion réussie! Bonjour %s!\n", u.login);
			
			return u;	
			
		}
	}


	//SI ON NE TROUVE PAS L'ID ET LE MDP ON REFAIT LA CONNEXION	
	printf("\nL'identifiant ou le mot de passe est incorrect. Veuillez réessayer.\n");
	return connection(p);
}

