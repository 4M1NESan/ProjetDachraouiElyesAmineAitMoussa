#ifndef __VERIF__
#define __VERIF__
int verification(char newid[], char newpassword[], FILE* p);
#endif