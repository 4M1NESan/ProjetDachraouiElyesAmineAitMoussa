# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include "connection.h"
#include"donLivre.h"
//don livre
void donLivre(FILE *p, Utilisateur u){
	Livre lidon, li;

	printf("\nVeuillez saisir le titre du livre que vous souhaitez donner.\n");
	getchar();
	scanf("%[^\n]",lidon.titre);
	rewind(p);

	while(fread(&li, sizeof(Livre), 1, p)!=0){
		if(strcmp(lidon.titre, li.titre)==0){
			printf("\nCe livre est déjà disponible dans notre bibliothèque. Merci quand même!\n");
			return ;
			
		}
	}


	printf("\nVeuillez saisir le prénom suivi du nom de l'auteur du livre que vous souhaitez donner.\n");
	getchar();
	scanf("%[^\n]",lidon.auteur);

	printf("\nVeuillez saisir la catégorie/genre du livre que vous souhaitez donner, sans mettre de majuscule.\n");
	scanf("%s",lidon.categorie);

	lidon.numid=(li.numid)+1;
	lidon.proprietaire[0]='o';
	lidon.proprietaire[1]='\0';

	//ajouter le livre a la bibliotheque
	fwrite(&lidon, sizeof(Livre), 1, p);
	printf("\nMerci pour votre donation! %s est maintenant disponible dans la bibliothèque.\n", lidon.titre);


}


