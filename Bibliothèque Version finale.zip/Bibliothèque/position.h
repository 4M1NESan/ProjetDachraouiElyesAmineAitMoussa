#ifndef __POSITION__
#define __POSITION__
#include"connection.h"
int positionUti(FILE* p, Utilisateur u);

#endif