#ifndef __DON__
#define __DON__
#include"connection.h"
void donLivre(FILE *p, Utilisateur u);

#endif