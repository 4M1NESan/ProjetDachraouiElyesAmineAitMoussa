# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include"recherches.h"
#include"connection.h"
//recherche genre
void rechercheGenre(FILE* p){
	Livre li;
	char recgenre[300];
	int  count=0;


	rewind(p);


	printf("\nVeuillez saisir la catégorie de livre que vous souhaitez rechercher.(sans mettre de majuscule)\n");
	scanf("%s",recgenre);


	while(fread(&li, sizeof(Livre), 1, p)!=0){
		if(strcmp(recgenre, li.categorie)==0){
			printf("\n%s de %s, catégorie %s\n", li.titre, li.auteur, li.categorie);
			count++;
		}
	}
	
	if(count==0)
		  printf("\nAucun livre ne correspond à votre recherche.\n");
}



//recherche auteur
void rechercheAuteur(FILE* p){
	Livre li;
	char recauteur[300];
	int  count=0;


	rewind(p);


	printf("\nVeuillez saisir le prénom puis le nom de l'auteur que vous souhaitez rechercher. [prénom] [nom]\n");
	getchar();
	scanf("%[^\n]",recauteur);

	while(fread(&li, sizeof(Livre), 1, p)!=0){
		if(strcmp(recauteur, li.auteur)==0){
			printf("\n%s de %s, catégorie %s\n", li.titre, li.auteur, li.categorie);
			count++;
		}
	}
	
	if(count==0)
		  printf("\nAucun livre ne correspond à votre recherche.\n");
}



//recherche titre
void rechercheTitre(FILE* p){
	Livre li;
	char rectitre[300];
	int  count=0;


	rewind(p);


	printf("\nVeuillez saisir le titre du livre que vous souhaitez rechercher.\n");
	getchar();
	scanf("%[^\n]",rectitre);


	while(fread(&li, sizeof(Livre), 1, p)!=0){
		if(strcmp(rectitre, li.titre)==0){
			printf("\n%s de %s, catégorie %s\n", li.titre, li.auteur, li.categorie);
			count=count+1;
		}
	}
	
	if(count==0)
		  printf("\nAucun livre ne correspond à votre recherche.\n");
	}


//afficher tous les livres
void rechercheAll(FILE* p){
	Livre li;
	char rectitre[300];
	
	rewind(p);

	while(fread(&li, sizeof(Livre), 1, p)!=0){
			printf("\n%s de %s, catégorie %s\n", li.titre, li.auteur, li.categorie);
	}

}

