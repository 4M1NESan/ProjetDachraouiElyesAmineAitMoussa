#ifndef __CONSTRUCTEUR__
#define __CONSTRUCTEUR__

void constructeur_uti(FILE* p);

#endif