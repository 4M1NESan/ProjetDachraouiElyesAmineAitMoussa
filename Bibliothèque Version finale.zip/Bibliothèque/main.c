# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include "verification.h"
#include"position.h"
#include"recherches.h"
#include"connection.h"
#include"constructeur_uti.h"
#include"donLivre.h"
#include"gestlivres.h"

int main(){
	//declaration des variables
	int choice, choiceprof=0, choiceetu=0, position, choicerec=0;
	Utilisateur u;
	FILE* plivre=NULL;
	FILE* puti=NULL;
	
	
	printf("\n****************************************************************************************************************\n");
	printf("\n                                    Bienvenu à la bibliothèque CY TECH                                        \n");
	printf("\n****************************************************************************************************************\n");
	printf("\n				Créée par Elyes DACHRAOUI et Amine AIT MOUSSA                                     \n");
	printf("\n****************************************************************************************************************\n");
	
	
	do{
		plivre=fopen("livres.bin", "rb+");
		puti=fopen("utilisateurs.bin", "rb+");
		choice=0;
		choiceprof=0;
		choiceetu=0;
		choicerec=0;
			
		//verifier si les fichiers sont bien ouverts	
		if (plivre==NULL ||puti==NULL){
			printf("\nIl y a eu une erreur lors de l'ouverture des fichiers. Veuillez réessayer.\n");
			exit(1);
		}
		
			//Connexion, inscription ou deconnexion
			do{
			printf("\nQue souhaitez-vous faire\n1.Connexion\n2.Inscription\n3.Quitter\n");
			scanf("%d", &choice);
		} while(choice!=1 && choice!=2 && choice!=3 && !(isalpha(choice)));
		
		
		
		
		
		
		//connexion
		if(choice==1){
			u=connection(puti);
			position=positionUti(puti, u);
			afficheLivre(plivre, u); 
			
			
			do{
				if(strcmp(u.role,"professeur")==0){
					do{
						printf("\nQue souhaitez-vous faire\n1.Emprunter un livre\n2.Rendre un livre\n3.Rechercher des livres\n4.Donner un livre\n5.Deconnexion\n");
						scanf("%d", &choiceprof);
					}while(choiceprof!=1 && choiceprof!=2 && choiceprof!=3 && choiceprof!=4 && choiceprof!=5);
				
				
					//emprunter un livre
					if(choiceprof==1){
						empruntLivre(u, plivre, puti, position);
					}
				
				
					//rendre un livre
					if(choiceprof==2){
						rendreLivre(u, plivre, puti, position);
					}
				
				
					//rechercher des livres 
					if(choiceprof==3){
						do{
							printf("\nQue souhaitez-vous rechercher?\n1.Un titre\n2.Une catégorie\n3.Un auteur\n4.voir tous les livre\n");
							scanf("%d", &choicerec);
						}while(choicerec!=1 && choicerec!=2 && choicerec!=3 && choicerec!=4);
						
						//rechercher titre
						if(choicerec==1){
							rechercheTitre(plivre);
						}
						
						//rechercher categorie/genre
						if(choicerec==2){
							rechercheGenre(plivre);
						}
						
						//rechercher un auteur
						if(choicerec==3){
							rechercheAuteur(plivre);
						}
						
						//rechercher tous les livres
						if(choicerec==4){
							rechercheAll(plivre);
						}
					}
					
					
					//donner un livre
					if(choiceprof==4){
						donLivre(plivre, u);
					}
					
				
				}
				
				else{
					do{
						printf("\nQue souhaitez-vous faire\n1.Emprunter un livre\n2.Rendre un livre\n3.Chercher des livres\n4.Deconnexion\n");
						scanf("%d", &choiceetu);
					}while(choiceetu!=1 && choiceetu!=2 && choiceetu!=3 && choiceetu!=4);
				
				
					//emprunter un livre
					if(choiceetu==1){
						empruntLivre(u, plivre, puti, position);
					}
				
				
					//rendre un livre
					if(choiceetu==2){
						rendreLivre(u, plivre, puti, position);
					}
					
					
				
					//rechercher des livres 
					if(choiceetu==3){
						do{
							printf("\nQue souhaitez-vous rechercher?\n1.Un titre\n2.Une catégorie\n3.Un auteur\n4.voir tous les livre\n");
							scanf("%d", &choicerec);
						}while(choicerec!=1 && choicerec!=2 && choicerec!=3 && choicerec!=4);
						
						//rechercher titre
						if(choicerec==1){
							rechercheTitre(plivre);
						}
						
						//rechercher categorie/genre
						if(choicerec==2){
							rechercheGenre(plivre);
						}
						
						//rechercher un auteur
						if(choicerec==3){
							rechercheAuteur(plivre);
						}
						
						//rechercher tous les livres
						if(choicerec==4){
							rechercheAll(plivre);
						}
					}
					
					
				}
				
				
				
			}while(choiceprof!=5 && choiceetu!=4);
		}
	
	
	
	
		//inscription
		if(choice==2){
			constructeur_uti(puti);
		}	
	
		fclose(plivre);
		fclose(puti);
	}while(choice!=3);
	
	printf("\nAu revoir!\n");
	
	return 0;
}
