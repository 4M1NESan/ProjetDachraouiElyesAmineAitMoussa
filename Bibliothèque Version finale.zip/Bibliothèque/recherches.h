#ifndef __RECHERCHE__
#define __RECHERCHE__
#include"connection.h"

void rechercheGenre(FILE* p);
void rechercheAuteur(FILE* p);
void rechercheTitre(FILE* p);
void rechercheAll(FILE* p);

#endif