# include <stdio.h>
# include <time.h>
# include <stdlib.h>
# include <string.h>
#include<ctype.h> 
#include "connection.h"
#include"constructeur_uti.h"

//creation compte
void constructeur_uti(FILE* p){
	//declaration des variables
	char c;
    int verif;
    Utilisateur u, u1;
	
	rewind(p);
	
	//recuoeration du role du nouvel utilisateur
	do{
		printf("\n Quel est votre role?(etudiant ou professeur) \n");
		scanf("%s",u.role);
		
		//pour le professeur
		if(strcmp(u.role,"professeur")==0){	
			u.compteur=5;
			u.bloque=0;
			do{
				printf("\n Bonjour, merci d'entrer vos nouvelles coordonnées.\n");
				printf("\n Quel est votre nouvel identifiant? Il ne doit contenir que des lettres.\n");
				scanf("%s",u.login);
				printf("\n Votre mot de passe?\n");
				scanf("%s",u.mot_de_passe);
				verif=verification(u.login, u.mot_de_passe, p);//verifier la validité
			}while(verif==0);
		}
		//pour l'etudiant
		else if(strcmp(u.role, "etudiant")==0){
			u.compteur=3;
			u.bloque=0;
			do{
				printf("\n Bonjour, merci d'entrer vos nouvelles coordonnées.\n");
				printf("\n Quel est votre identifiant? Il ne doit contenir que des lettres. \n");
				scanf("%s",u.login);
				printf("\n Votre mot de passe?\n");
				scanf("%s",u.mot_de_passe);
				verif=verification(u.login, u.mot_de_passe, p);
			}while(verif==0);
		}
		else{
        printf("\nIl y a une erreur de role merci de ressaisir votre role\n");
		}
	}while(strcmp(u.role,"professeur")!=0 && strcmp(u.role,"etudiant")!=0);


	rewind (p);
	
	
	//inscrire le nouvel utilisateur dans le fichier utilisateur
	while(fread(&u1, sizeof(Utilisateur), 1, p)!=0){
		printf("\n...\n");	
	}
	

	fwrite(&u, sizeof(Utilisateur), 1, p);
	printf("\nInscription réussie!! Bienvenue parmi nous %s!!\n", u.login);
}

